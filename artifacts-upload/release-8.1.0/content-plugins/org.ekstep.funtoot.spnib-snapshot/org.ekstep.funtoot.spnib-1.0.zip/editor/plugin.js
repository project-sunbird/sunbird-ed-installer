//@ sourceURL=spnib-plugin.js
/**
 * Editor plugin for the spnib template
 * @extends org.ekstep.contenteditor.basePlugin
 * @author Sandhya M <sandhya.m@funtoot.com>
 */
org.ekstep.funtoot.common.extend({
    /**
     * This expains the type of the plugin 
     * @member {String} type
     * @memberof spnib
     */
    type: "org.ekstep.funtoot.spnib",
    /**
   * registers events
   *  @memberof spnib
   */
    initialize: function () {
        var id = this.manifest.id;
        var version = this.manifest.ver;
        ecEditor.addEventListener(this.manifest.id + ":showpopup", this.showDialog, this);
        ecEditor.addEventListener(this.manifest.id + ":renderFabricContent", this.renderFabricContent, this);
        setTimeout(function () {
            var templatePath = ecEditor.resolvePluginResource(id, version, manifest.editor.wizard.template);
            var controllerPath = ecEditor.resolvePluginResource(id, version, manifest.editor.wizard.controller);
            ecEditor.getService('popup').loadNgModules(templatePath, controllerPath);
        }, 1000);

    },
    /**
    * loads the image depending on the question configuration and adds to the fabric object 
    *  @memberof funtoot-common
    */
    loadFabricImage: function () {
        var id = this.manifest.id;
        var version = this.manifest.ver;
        var instance = this;
        var fabricImg = ecEditor.resolvePluginResource(id, version, "/editor/assets/sucessor-predecessor-fabric.png");
        if (instance.data.items[instance.data.item_sets[0].id][0].model.cols == 3)
            fabricImg = ecEditor.resolvePluginResource(id, version, "/editor/assets/numberInBetween-fabric.png");
        fabric.Image.fromURL(fabricImg, function (img) {
            console.log(img.width + 'x' + img.height + '(' + img.x + ',' + img.y + ')')
            instance.editorObj.addWithUpdate(img);
        }, instance.convertToFabric(instance.attributes));
    },
    /**        
     *   shows the dialog for editing the questions
     *   @param {object} event the event
     *   @param {function} callback the callback to call after the question is configured
     *   @memberof spnib
     */
    showDialog: function (event, callback) {
        var instance = this;
        instance.callback = this.controllerCallback;
        ecEditor.getService('popup').open({
            template: 'spnib',
            controller: 'spnibController',
            controllerAs: '$ctrl',
            resolve: {
                'instance': function () {
                    return instance;
                }
            },
            width: 900,
            showClose: false,
            className: 'ngdialog-theme-plain'
        });
    }
});
