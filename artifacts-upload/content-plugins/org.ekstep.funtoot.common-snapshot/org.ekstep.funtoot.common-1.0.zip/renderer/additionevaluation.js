//@ sourceURL=additionevaluation.js
/* global PluginManager */
/**
 * 
 * @extends Plugin
 */
Plugin.extend({
    _type: 'org.ekstep.funtoot.additionevaluation',
    /**
     * initializes the grid plugin
     * @param {Object} data the data for the addition evaluation plugin
     */
    initPlugin: function (data) {

    },
    /**
     * If the addends are multiples of 100s
     * @param {Object} model addition evaluation model
     * @returns {boolean}
     */
    multiplesOfHundreds: function (model) {

    },
    /**
     * Carry is reversed - units digit of the sum is considered as carry digit
     * eg:23 + 59 
     * =>91 (23 + 59 = 82)
     * @param {Object} model addition evaluation model
     * @returns {boolean} 
     */
    reverseCarry: function (model) {

    },
    /**
     * Carry is missed - carry digit is not considered in addition
     * eg: 53 + 69 
     * => 112 (left the carryover at the tens place.)
     * @param {Object} model addition evaluation model
     * @returns {boolean}
     */
    carryMissing: function (model) {

    },
    /**
     * Adding from higher placevalue and go to lower placevalue
     * eg:
     * 53 + 69
     * =>113 - adding from the tens and go to units.
     * @param {Object} model addition evaluation model
     * @returns {boolean} 
     */
    reverseAddition: function (model) {

    },
    /**
     * 
     */
    carryInAnswerBox: function (model) {

    },
    /**
     * 
     */
    additionOfIndividualDigits: function (model) {

    },
    /**
     * 
     */
    joinNumbers: function (model) {

    }

});
