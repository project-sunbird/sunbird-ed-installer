//@ sourceURL=inlineFib.js
/* global PluginManager */
/**
 
 */
Plugin.extend({
    _type: 'inlineFib',
    /**
     * initializes the plugin
     */
    initPlugin: function (data) {
        var contentContainer = this._parent;
        this._cells = [];
        var instance = this;
        var inlineTxtContainer = {
            id: "inlineTxtContainer",
            w: 80, h: 70, y: 20, x: 10,
            align: "center",
            valign: "middle",
        }
        PluginManager.invoke('g', inlineTxtContainer, contentContainer, this._stage, this._theme);
        var debug1 = {
            w: 80, h: 70, y: 10, x: 10,
            type: "rect",
            stroke: "red",
        }

        //PluginManager.invoke('shape', debug1, contentContainer, this._stage, this._theme);
        var txtContainer = PluginManager.getPluginObject("inlineTxtContainer");

        var wordXPosition = 0;
        var wordYPosition = 0;

        _.each(data.tokens, function (token) {
            var phantomTxt = {
                id: _.uniqueId('txt'),
                y: wordYPosition, x: wordXPosition,
                fontsize: "2.7vw",
                align: "center",
                valign: "middle",
                $t: token.content,
                color: "#60BC50",
                visible: false
            }
            PluginManager.invoke('text', phantomTxt, txtContainer, instance._stage, instance._theme);

            var txtObj = PluginManager.getPluginObject(phantomTxt.id);
            var blankXPadding = (token.w) ? 10 : 0;
            var blankYPadding = (token.w) ? 2 : 0;
            var wordWidth = ((txtObj._self.getBounds().width) / (txtContainer._self.width) * 100);
            wordWidth = wordWidth + blankXPadding;
            var wordHeight = (txtObj._self.getBounds().height) / (txtContainer._self.height) * 100;
            wordHeight = wordHeight + blankYPadding;
            if (wordXPosition + wordWidth > 100) {
                wordXPosition = 0;
                //4 percent spacing between lines
                wordYPosition = wordYPosition + wordHeight + 6;
            }
            var cell = {
                id: token.id,
                w: wordWidth, h: wordHeight, y: wordYPosition, x: wordXPosition,
            }

            PluginManager.invoke('g', cell, txtContainer, instance._stage, instance._theme);
            var cellObj = PluginManager.getPluginObject(cell.id);
            instance._cells.push(cellObj);
            var debug2 = {
                id: _.uniqueId('txt-shape'),
                w: wordWidth, h: wordHeight, y: wordYPosition, x: wordXPosition,
                type: "rect",
                stroke: "black",
            }

            //PluginManager.invoke('shape', debug2, txtContainer, instance._stage, instance._theme);
            //1.5 percent spacing between words
            wordXPosition = wordXPosition + wordWidth + 1.5;
        });
    },

    /**
         * returns the cell at the specified colIndex
         * @param {number} colIndex the column index of the cell 
         */
    getCell: function (colIndex) {
        return this._cells[colIndex];
    }
});